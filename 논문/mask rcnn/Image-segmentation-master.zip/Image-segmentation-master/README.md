# Image-segmentation

Human remove using MASK_RCNN
----------------------------
1. auto search Human object (COCO dataset lebel)
2. human area remove RGBA--> alpha value = 0

Enviorment
-----------
1. torch version >=1.8.1
2. torch cuda >= 10.2
3. torch vision >= 0.9.1

For example
----------------------------
## Input image

![Alt text](/images/1111.jpg)

## Output image

![Alt text](/output/output_1.jpg)
![Alt text](/output/output_2.jpg)
